#### This project contains only one class (main), it is used to validate JSON documents w.r.t JSON schemas.

#### The validator used is https://github.com/networknt/json-schema-validator (version 1.0.65).
#### This main class needs 2 parameters : 
        - The path to the folder containing the schemas.
        - The path to the folder containing the witnesses.
          The name of a witness should be as follow : schemaName_witness.json where schemaName 
          is the schema id (the name of the file without the extension).

#### After the execution, this class produces 2 csv files :
        - validation.csv : contains the 2 columns objectId (name of a schema without the extension 
          and valid (true if the witness corresponding to the schema is correct, false otherwise).
        - validationErrors.csv : contains the validation errors when we have a non-valid witness.
          Contains 4 columns : objectId, number of errors, type of errors and the errors messages.
    