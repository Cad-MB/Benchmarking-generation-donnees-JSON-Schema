import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.*;
import org.apache.commons.text.StringEscapeUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class WitnessValidation {


    private static Pattern p4 = Pattern.compile("/draft-04/");
    private static Pattern p6 = Pattern.compile("/draft-06/");
    private static Pattern p7 = Pattern.compile("/draft-07/");
    private static Pattern regexXbool = Pattern.compile("(\"exclusiveMinimum\"|\"exclusiveMaximum\"):(false|False|true|True)");



    public static SpecVersion.VersionFlag getVersionFlag(String pathToFile) throws IOException {
        SpecVersion.VersionFlag version = SpecVersion.VersionFlag.V201909;


        String s = Files.readString(Path.of(pathToFile));
        s = s.replace(" ","");

        if(p4.matcher(s).find() || regexXbool.matcher(s).find())
            version = SpecVersion.VersionFlag.V4;
        else if(p6.matcher(s).find())
            version = SpecVersion.VersionFlag.V6;
        else if(p7.matcher(s).find())
            version = SpecVersion.VersionFlag.V7;

        return version;
    }


    public static Set<ValidationMessage> validateStringWitness(String schemaString, String witness, SpecVersion.VersionFlag version) throws
            JsonSchemaException,JsonProcessingException  {

        JsonSchemaFactory factory = JsonSchemaFactory.getInstance(version);

        ObjectMapper mapper = new ObjectMapper();


        JsonSchema schema = null;
        schema = factory.getSchema(schemaString);

        JsonNode node = null;
        node = mapper.readTree(witness);

        Set<ValidationMessage> errors = schema.validate(node);



        return errors;
    }



    static void writeOnErrorsFile(String id, Set<ValidationMessage> errors, BufferedWriter errorsFile) throws IOException {
        String w = "";

        List<String> errorsTypes = errors.stream().map(m -> m.getType()).collect(Collectors.toList());

        String s1 = "";
        for (int i=0; i<errorsTypes.size();i++) {
            String errorType = errorsTypes.get(i);
            s1 = s1.concat(errorType);
            if(i<errorsTypes.size()-1)
                s1 = s1.concat(",");
        }

        s1 = StringEscapeUtils.escapeCsv(s1);



        String s2 = "";
        int i=0;
        for(Iterator<ValidationMessage> it = errors.iterator(); it.hasNext(); ){
            i++;
            String message = it.next().getMessage();
            s2 = s2.concat(message);
            if(i<errors.size()-1)
                s2 = s2.concat(",");
        }

//        String errorsMessagesString = StringEscapeUtils.escapeCsv(sb2.toString());


        s2 = s2.replace(",","    ");
        w = w.concat(id+","+errors.size()+","+s1+","+s2+"\n");
        errorsFile.write(w);
    }


    public static String getSchemaId(File file){
        return file.getName().replaceAll(".json","");
    }




    static BufferedWriter createBufferedWriter(String path, String filename) {
        BufferedWriter bw;
        File file = new File(path + "/" + filename);
        try {
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            bw = new BufferedWriter(fw);
            return bw;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) throws IOException {

        if (args.length < 2) {
            System.out.println("Usage: <path>");
            return;
        }

        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy_HHmmss");
        Date date = new Date();

        String pathToSchemas = args[0];
        File[] schemas = new File(pathToSchemas).listFiles();
        Arrays. sort(schemas, Comparator.comparing(f -> f.length()));

        String pathToWitnesses = args[1];
        File[] witnesses = new File(pathToWitnesses).listFiles();
        Arrays. sort(witnesses, Comparator.comparing(f -> f.length()));

        BufferedWriter validationFile = createBufferedWriter(pathToWitnesses,"validation_"+formatter.format(date)+".csv");
        validationFile.write("objectId,valid\n");

        BufferedWriter validationErrorsFile = createBufferedWriter(pathToWitnesses,"validationErrors_"+formatter.format(date)+".csv");
        validationErrorsFile.write("objectId,nbErrors,errorsTypes,errorsMessages\n");


        for (File schemaName : schemas){
            if (!schemaName.getName().endsWith(".json")) {
                System.out.println("skipping non-json file: " + schemaName.getName()+"\n\n");
                continue;
            }

            String objectId = getSchemaId(schemaName);

            String schema = Files.readString(Path.of(schemaName.getPath()));

            String witness;
            try {
                witness = Files.readString(Path.of(pathToWitnesses+"/"+objectId+"_witness.json"));
            } catch (NoSuchFileException e) {
                System.out.println(e);
                continue;
            }

            if (witness.length()==0)
                continue;

            System.out.println("Validating the witness of "+schemaName+" (size : "+schemaName.length()+")");


            SpecVersion.VersionFlag version = getVersionFlag(schemaName.getPath());
            Set<ValidationMessage> errors;
            try {
                errors = validateStringWitness(schema,witness,version);
            } catch (Exception e) {
                validationFile.write(objectId+","+e.getClass()+"\n");
                System.out.println(e.getClass());
                continue;
            } catch (StackOverflowError e) {
                validationFile.write(objectId+","+e.getClass()+"\n");
                continue;
            }


            if (errors.size()==0)
                validationFile.write(objectId+",TRUE\n");
            else if (errors.size()>0) {
                validationFile.write(objectId+",FALSE\n");
                writeOnErrorsFile(objectId,errors,validationErrorsFile);
            }

            else {
                validationFile.write(objectId+",ValidationException\n");
            }

        }
        validationFile.flush();
        validationFile.close();

        validationErrorsFile.flush();
        validationErrorsFile.close();



    }


}
