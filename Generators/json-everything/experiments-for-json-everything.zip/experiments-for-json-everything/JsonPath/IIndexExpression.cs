﻿namespace Json.Path;

internal interface IIndexExpression
{
}