﻿using System.Collections.Generic;

namespace Json.Path.Tests.Suite;

public class ComplianceTestSuite
{
	public List<ComplianceTestCase> Tests { get; set; }
}