﻿namespace JsonPointer.Benchmark
{
	class Program
	{
		// ReSharper disable once UnusedParameter.Local
		static void Main(string[] args)
		{
			ParseTests.Run();
			EvaluateTests.Run();
		}
	}
}