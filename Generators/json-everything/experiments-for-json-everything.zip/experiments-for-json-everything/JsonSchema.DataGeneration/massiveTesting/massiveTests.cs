﻿using static Json.Schema.JsonSchema;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace Json.Schema.DataGeneration.massiveTesting;


class massiveTesting {
  
    static int Main(String[] args)
    {
        String pathToDataset = "/home/lyes/JSONGEN/expdataset/test";

        DirectoryInfo pathToFolder = new DirectoryInfo(pathToDataset);

        FileInfo [] fileEntries = pathToFolder.GetFiles("*.json").OrderBy(f => f.Length).ToArray();
        
        DirectoryInfo resultsFolder = null;
        try
            {
                if (!Directory.Exists(pathToFolder+"/JSONEverythingResults"))
                {
                    // Try to create the directory.
                    resultsFolder = Directory.CreateDirectory(pathToFolder+"/JSONEverythingResults");
                }
                else {
                    resultsFolder = new DirectoryInfo(pathToFolder+"/JSONEverythingResults");
                }
            }
        catch (IOException ioex)
            {
                Console.WriteLine(ioex.Message);
            }
            
        
        DateTime d = DateTime.Now;
        String date = d.ToString("ddMMyyyy_HHmmss");

        using (var res = new StreamWriter(resultsFolder+"/JSONEverythingResults_"+date+".csv",true))
        using (var excep = new StreamWriter(resultsFolder+"/JSONEverythingException_"+date+".csv",true))
        {
            var resHeader = string.Format("objectId,inSize,totalTime,generated");
            res.WriteLine(resHeader);
            res.Flush();

            var exceptHeader = string.Format("objectId,exceptionMessage");
            excep.WriteLine(exceptHeader);
            excep.Flush();

            foreach(FileInfo file in fileEntries) {

                var watch = new System.Diagnostics.Stopwatch();

                string fileName = file.Name;
                string name = fileName.Remove(fileName.Length-5);
                string size = file.Length.ToString();

                Console.Write(DateTime.Now);
                Console.WriteLine(" : started processing "+fileName+ " (size : "+file.Length+")");

                watch.Start();

                JsonSchema schema = null;
                JsonNode result = null;
                Boolean generated = false;
                try {
                    schema = FromFile(pathToFolder+"/"+fileName);
                } catch(Exception e) {
                    generated = false;
                    var line = string.Format("{0},{1}",name,e.Message);
                    excep.WriteLine(line);
                    excep.Flush();
                    Console.WriteLine(e.Message);
                }

                if (schema != null) {
                
                    var task = Task.Run(() => schema.GenerateData());
                    try {
                        if (task.Wait(TimeSpan.FromSeconds(60))) {
                            if (task.Result.Result != null)
                                result = task.Result.Result;
                                generated = true;
                        }
                    } catch (Exception e){
                        generated = false;
                        var line = string.Format("{0},{1}",name,e.Message);
                        excep.WriteLine(line);
                        excep.Flush();
                        Console.WriteLine(e.Message);
                    }
                
                }

                watch.Stop();

                string totalTime = watch.ElapsedMilliseconds.ToString();                
                

                var lineR = string.Format("{0},{1},{2},{3}",name,size,totalTime,generated);
                res.WriteLine(lineR);
                res.Flush();

                if (File.Exists(resultsFolder+"/"+name+"_witness.json")) {
                    File.Delete(resultsFolder+"/"+name+"_witness.json");
                }

                if(generated == false) {
                        continue;
                }

                using (var witnessW = new StreamWriter(resultsFolder+"/"+name+"_witness.json",true)) {
                    var text = string.Format("{0}",result);
                    witnessW.WriteLine(text);
                    witnessW.Flush();
                }
            }
        }

        return 0;
    }
}