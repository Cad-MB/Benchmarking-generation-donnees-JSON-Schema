### To run the experiments :
- Open the folder massiveTesting located in JsonSchema.DataGeneration with VS code 
- In the massiveTests.cs, modify the value of pathToFolder to the folder containing the schemas to test.
- Then, in the terminal execute dotnet run.