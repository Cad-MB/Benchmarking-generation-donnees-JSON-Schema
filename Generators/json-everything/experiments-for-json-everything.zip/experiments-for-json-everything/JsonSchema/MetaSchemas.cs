﻿namespace Json.Schema;

/// <summary>
/// Exposes the meta-schemas for the supported drafts.
/// </summary>
public static partial class MetaSchemas
{
}